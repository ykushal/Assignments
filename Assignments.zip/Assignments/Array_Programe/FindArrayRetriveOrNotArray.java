class FindArrayRetriveOrNotArray
{
	public static void main(String[] args)
	{
		int[][] a = new int[2][3];
	
	
		System.out.println("a is = " + a);
		System.out.println("a[0] is = " + a[0]);
		System.out.println("a[0][0] is = " + a[0][0]);
		System.out.println("a is = " + a.length);
		
		
	}
}