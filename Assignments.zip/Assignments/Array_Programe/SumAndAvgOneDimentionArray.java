class SumAndAvgOneDimentionArray
{
public static void main(String[] args)
{
	int[] arry = new int[]{10,23,33,45,75,79,99};
	int i,sum = 0;
	double avg;
	for(i = 0; i <arry.length; i++)
	{
		sum = sum + arry[i];
	}
	avg = sum / arry.length;
	System.out.println("sum is = " + sum);
	System.out.println("avg is = " + avg);
	
	
}

}