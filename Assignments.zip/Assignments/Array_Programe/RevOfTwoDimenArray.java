class RevOfTwoDimenArray
{
	public static void main(String[] args)
	{
		int[][] arry= new int[2][2];
		int arg1 = Integer.parseInt(args[0]);
		int arg2 = Integer.parseInt(args[1]);
		int arg3 = Integer.parseInt(args[2]);	
		int arg4 = Integer.parseInt(args[3]);
		arry[0][0]=Integer.parseInt(args[0]);
		arry[0][1]=Integer.parseInt(args[1]);
		arry[1][0]=Integer.parseInt(args[2]);
		arry[1][1]=Integer.parseInt(args[3]);
		int i,j;
		if(args.length <= 4)
		{
			
			System.out.println("reverse of rgument is =");
			for(i = 1; i >= 0; i--)
			{
				for(j= 1; j >=0; j--)
				{
					System.out.print(arry[i][j] + "\t");
				}
					System.out.println("");
			}
			
		}
		else
		{
			System.out.println("Enter the argument 4");
		}
	}
}