class MaxAndMinArray
{
	public static void main(String[] args)
	{
	  int arry[] = new int[]{1,2,3,42,3,5,3,57,8,9,99};
      int s = arry[0];
      int l = arry[0];
      
      for(int i = 1; i < arry.length; i++) 
	  {
         if(arry[i] > l)
		 {
			 l = arry[i];
		 }
         else if (arry[i] < s)
			 {
				 s = arry[i];
			 }
      } 
      System.out.println("Maximum Number is : " + l);
      System.out.println("Minimum Number is : " + s);
		
		
		
	}
}