package BankATMExample;
import java.io.IOException;
public class ATM extends OptionMenu {
	public static void main(String[] args) throws IOException {
		OptionMenu om= new OptionMenu();
		om.getLogin();

}
}
