class PatternBasicTriangle
{

public static void main(String[] args)
{
	int row = Integer.parseInt(args[0]);
	int i,j ;
	for(i = 0; i < row; i++)
	{
		for(j=0; j<=i; j++)
		{
			System.out.print("*");
		}
		System.out.println(" ");
	}
}
}