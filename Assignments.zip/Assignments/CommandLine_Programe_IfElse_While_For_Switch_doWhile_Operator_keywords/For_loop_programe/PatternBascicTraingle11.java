class PatternBascicTraingle11
{
public static void main(String[] args)
{
	int row = Integer.parseInt(args[0]);
	int i,j;
	for(i = 0; i < row; i++)
	{
		for(j= 0; j<=i; j++)
		{
			System.out.print("*");
			
		}
		System.out.println("");
	}
	for(i = row; i > 0; i--)
	{
		for(j = 1; j < i; j++)
		{
			System.out.print("*" );
		}
		System.out.println("");
	}
}

}