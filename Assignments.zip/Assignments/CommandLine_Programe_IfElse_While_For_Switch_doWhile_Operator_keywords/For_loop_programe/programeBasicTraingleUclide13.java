class programeBasicTraingleUclide13
{
	public static void main(String[] args)
	{
		int row = Integer.parseInt(args[0]);
		int i,j;
		int x = 0;
		for(i = 1; i<=row; i++ )
		{
			
			for(j = 1; j<=i; j++)
			{
				
				System.out.print( (j + x)  +"\t");
				
			}
			x = i + x;
				System.out.println("");
		}
	}

}