class FebonacciSerise
{
	public static void main(String[] args)
	{
		int num = Integer.parseInt(args[0]);
		int a = -1, b= 1;
		int 	i;
		for(i =1; i<= num; i++)
		{
			int c = a + b;
			System.out.print( c + "\t" );
			a = b;
			b = c;
		} 
	}
}