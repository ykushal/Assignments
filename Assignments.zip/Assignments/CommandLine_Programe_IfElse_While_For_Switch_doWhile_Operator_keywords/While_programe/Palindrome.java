class Palindrome
{

	public static void main(String[] args)
		{
			int num = Integer.parseInt(args[0]);
			int temp = num,sum =0,rem ;
			while(temp != 0)
			{
				rem = temp % 10;
				sum = sum * 10 + rem;
				temp= temp /10;
			}
			if (sum == num)
				System.out.println("number is palindrome" + num);
			else
				System.out.println("number is not in palindrome" + num);
		}
}