import logo from './logo.svg';
import React,{Component} from 'react';
import './App.css';

class App extends React.Component {
	constructor()
	{
		super();
		this.state= {status:false};
		this.changeState=this.changeState.bind(this);
	}
	changeState()
	{		
	  this.setState({status : !this.state.status});	
	}
	render(){
		const msg=this.state.status ?(<div><h2 className='strue'>Status is true</h2>
		 <button onClick={this.changeState}>Set state false!</button>
		</div>) :(<div><h4 className='sfalse'>Status is false</h4>
		<button onClick={this.changeState}>Set state true!</button>
		</div>) ;
  return (
    <div className="App">
	{msg}
    </div>
  );
}
}
export default App;
