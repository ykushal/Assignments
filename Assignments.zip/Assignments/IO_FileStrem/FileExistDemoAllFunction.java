import java.io.File;
import java.io.IOException;
class FileExistDemoAllFunction
{
public static void main(String[] args) throws Exception 
{	
File f = new File("C:/Users/Sandeep.D/Desktop/FileIO/abc.txt");
	f.createNewFile();
	System.out.println(f.exists());
	System.out.println(f.canWrite());
	System.out.println(f.getName());
	System.out.println(f.length());
	
}
}