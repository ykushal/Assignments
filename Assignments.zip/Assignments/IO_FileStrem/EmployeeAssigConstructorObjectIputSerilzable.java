import java.io.File;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.Serializable;
import java.io.ObjectInputStream;


class EmployeeAssigConstructorObjectIputSerilzable
{
		public static void main(String[] args) throws IOException,ClassNotFoundException
		{	
		
			File file = new File("C:/Users/Sandeep.D/Desktop/FileIO/yash.txt");
			FileInputStream finput=new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(finput);
			Employee e =(Employee)ois.readObject();
			String nameOfa;
			System.out.println(nameOfa = e.name);
			System.out.println(nameOfa);
			System.out.println(e.department);
			System.out.println(e.designation);
			System.out.println(e.salary);
			ois.close();
			finput.close();
			
		}
}