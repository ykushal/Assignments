import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
class FileWriterReader
{ 
	public static void main(String[] args)throws IOException
	{
		File file = new File("C:/Users/Sandeep.D/Desktop/FileIO/filewriteread.txt");
		file.createNewFile();
		FileWriter wr = new FileWriter(file);
		wr.write("This is a file write or read file");
		wr.close();
		
		FileReader fr = new FileReader(file);
		char c[] = new char[30];
		fr.read(c);
		for(char a:c)
		{
			System.out.print(a);
		}
	
		fr.close();
	}
}