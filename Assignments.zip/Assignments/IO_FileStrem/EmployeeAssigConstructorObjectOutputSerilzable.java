import java.util.Scanner;
import java.io.ObjectOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.Serializable;


class Employee implements Serializable
{
	String name;
	String department;
	String designation;
	double salary;
	Employee(String name,String department,String designation,double salary)
	{
		
		this.name=name;
		this.department = department;
		this.designation = designation;
		this.salary=salary;
		
	}
	Employee()
	{
		this("Abc","CSE","Java Developer",999999999.0);
		System.out.println("name is = " + this.name);
		System.out.println("department is = " + this.department);
		System.out.println("designation is = " + this.designation);
		System.out.println("salary is = " + this.salary);	
	}
			
	}


class EmployeeAssigConstructorObjectOutputSerilzable
{
		public static void main(String[] args) throws IOException,ClassNotFoundException
		{	
			Employee e = new Employee();
		
			File file = new File("C:/Users/Sandeep.D/Desktop/FileIO/yash.txt");
			file.createNewFile();
			ObjectOutputStream oosf= new ObjectOutputStream(new FileOutputStream(file));
			oosf.writeObject(e);
			oosf.close();
		}
}