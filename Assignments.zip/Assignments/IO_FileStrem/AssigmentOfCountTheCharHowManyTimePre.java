import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;
class AssigmentOfCountTheCharHowManyTimePre
{
	public static void main(String[] args) throws Exception
	{
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter the char");
		String st =obj.nextLine();
		File f = new File("C:/Users/Sandeep.D/Desktop/FileIO/abc.txt");
		char ch = st.charAt(0);
		String fname = f.getName();
		FileInputStream file = new FileInputStream(f);
		
		int count_ch = 0; 
		int i;
		while((i = file.read()) != -1)
		{
			if((char) i == ch)
			{
				count_ch++;
			}
		
		}
		file.close();
		System.out.println(fname + "file the prsent "+ count_ch + " istance of letter " + ch + "in " ) ;
	
		
	}
}