import java.io.FileInputStream;
import java.io.BufferedInputStream;
class BufferInputStream
{
	public static void main(String[] args)
	{
		try
		{
			FileInputStream fin = new FileInputStream("C:/Users/Sandeep.D/Desktop/FileIO/abc.txt");
			BufferedInputStream binput = new BufferedInputStream(fin);
			int i;
			while((i = binput.read()) != -1)
				{
					System.out.print((char)i);
				}
			binput.close();
			fin.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}


	}
}