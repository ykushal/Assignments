import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
class AssigmentOfCountNumberWordsLine
{
	public static void main(String[] args) throws Exception
	{
		FileInputStream file = new FileInputStream("C:/Users/Sandeep.D/Desktop/FileIO/abc.txt");
		int count_ch = 0,count_line = 1,count_words = 0,count_space=0; 
		int i;
		while((i = file.read()) != -1)
		{
			if((char) i != ' ')
			{
				count_ch++;
			}
			if((char) i == ' ')
			{
				count_space++;
			}
			if((char) i == '\n')
			{
				count_line++;
			}
		}
		file.close();
		System.out.println("char is = " + count_ch);
		System.out.println("word is = " + count_words);
		System.out.println("space is = " + count_space);
		System.out.println("line is = " + count_line);
		
	}
}