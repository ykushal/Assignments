import java.io.*;
class Employee implements Serializable
{
	int empId;
	String empName;
	Employee(int empId,String empName)
	{
		this.empId = empId;
		this.empName = empName;
	}
	public String toString()
	{
		return empId + " " + empName;
	}
}
class EmployeeAssigObjectInputStream
{
	public static void main(String[] args) throws Exception
	{
		
		
		File f = new File("C:/Users/Sandeep.D/Desktop/FileIO/abc.txt");
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
		Employee e =(Employee)ois.readObject();
		System.out.println(e);
		ois.close();
		
		
	}
}