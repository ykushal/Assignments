import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
class AssigmentOfVowelCount
{
	public static void main(String[] args) throws Exception
	{
		FileInputStream file = new FileInputStream("C:/Users/Sandeep.D/Desktop/FileIO/abc.txt");
		int a=0, e=0,i=0,o=0,u=0,total =0; 
		int h;
		while((h = file.read()) != -1)
		{
			if((char) h == 'a' || (char) h == 'A'||(char) h == 'e'||(char) h == 'E'||(char) h == 'i' || (char) h == 'I'||(char) h == 'o'||(char) h == 'O'||(char) h == 'u'||(char) h == 'U')
			{
				if((char)h == 'a' || (char) h == 'A')
				{
					a++;
				}
				if((char)h == 'e' || (char) h == 'E')
				{
					e++;
				}
				if((char)h == 'i' || (char) h == 'I')
				{
					i++;
				}
				if((char)h == 'o' || (char) h == 'O')
				{
					o++;
				}
				if((char)h == 'u' || (char) h == 'U')
				{
					u++;
				}
				total++;
			}
		}
		file.close();
		System.out.println(" a is = " + a);
		System.out.println("e is = " + e);
		System.out.println("i is = " + i);
		System.out.println("o is = " + u);
		System.out.println("u is = " + u);
		System.out.println("total is = " + total);

		
	}
}