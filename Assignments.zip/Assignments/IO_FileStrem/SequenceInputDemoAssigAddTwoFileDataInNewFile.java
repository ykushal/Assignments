import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.SequenceInputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.BufferedOutputStream;
class SequenceInputDemoAssigAddTwoFileDataInNewFile
{
	public static void main(String[] args) throws IOException
	{
		File file = new File("C:/Users/Sandeep.D/Desktop/FileIO/compile.txt");
		file.createNewFile();
		FileInputStream file1 = new FileInputStream("C:/Users/Sandeep.D/Desktop/FileIO/abc.txt");
		FileInputStream file2 = new FileInputStream("C:/Users/Sandeep.D/Desktop/FileIO/filewrieread.txt");
		SequenceInputStream si = new SequenceInputStream(file1,file2);
		FileOutputStream file3 = new FileOutputStream("C:/Users/Sandeep.D/Desktop/FileIO/compile.txt");
		BufferedOutputStream boutput = new BufferedOutputStream(file3);
		int i;
		while( (i = si.read()) != -1)
		{
			boutput.write((char) i);
		}
		boutput.close();
		file1.close();
		file2.close();
		file3.close();
		
		si.close();
	}
}