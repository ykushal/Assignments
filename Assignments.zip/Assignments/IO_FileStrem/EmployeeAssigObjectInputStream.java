import java.util.Scanner;
import java.io.ObjectOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.Serializable;

import java.io.ObjectInputStream;
import java.io.FileInputStream;

class EmployeeAssigObjectInputStream implements Serializable
{
	
	
	public static void main(String[] args) throws IOException,ClassNotFoundException
	{	
		
		
		File file2 = new File("C:/Users/Sandeep.D/Desktop/FileIO/yash.txt");
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file2));
		EmployeeAssig e =new EmployeeAssig();
		e = (EmployeeAssig)ois.readObject();
		System.out.println(e.getEmployee());
		ois.close();
		
	}

}