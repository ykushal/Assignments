import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
class InputWriteREadFileByThrows
{
	public static void main(String[] args) throws IOException 
	{
		FileInputStream filein = new FileOutputStream("C:/Users/Sandeep.D/Desktop/FileIO/abc.txt");
		FileOutputStream fileout = new FileOutputStream("C:/Users/Sandeep.D/Desktop/FileIO/filewriteread.txt");
	}
}