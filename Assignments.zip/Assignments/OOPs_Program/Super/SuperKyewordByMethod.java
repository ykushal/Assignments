class SuperKeyWordMathod
{
	String name;
	void show(String name)
	{
		this.name = name;
		System.out.println("SuperKeyWord Class Mathod call and Name is = " + name);
	}
}
class SuperKyewordByMethod extends SuperKeyWordMathod
{
	String name;
	void show(String name)
	{
		this.name = name;
		System.out.println("B Class Mathod call and Name is = " + name);
	}
	void display()
	{
		show("ABC");
		super.show("ABCCC");
	}
	public static void main(String[] args)
	{
		SuperKyewordByMethod obj = new SuperKyewordByMethod();
		obj.display();
	}
}