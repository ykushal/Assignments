class SuperKeyWord
{
	int num = 100;
	
	
}
class SuperKeywordVaribal extends SuperKeyWord
{
	int num = 500;
	void show(int num)
	{
		System.out.println("Pass argument only num = "  + num);
		System.out.println("This KeyWord num = "  + this.num);
		System.out.println("Super KeyWord num = "   + super.num);
	}
	
	public static void main(String[] args)
	{
		SuperKeywordVaribal obj = new SuperKeywordVaribal();
		obj.show(300);
	}
	
}