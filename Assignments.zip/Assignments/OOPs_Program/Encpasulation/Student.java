class Student
{   
    private String stu_Name;
	public String setStuData(String stu_Name)
	{
		this.stu_Name = stu_Name;
		return stu_Name; 
	}
	public String getStuData()
	{
		return stu_Name;
	}
	
}
class Display
{
	public static void main(String[] args)
	{
		Student obj = new Student();
		String a = obj.setStuData("Abc");
		System.out.println("Name of Student is = " + a);
	}
}