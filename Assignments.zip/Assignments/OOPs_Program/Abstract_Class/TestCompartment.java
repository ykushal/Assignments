import java.util.Random;
abstract class Compartment
{
	public abstract String notice(); 
}
class FirstClass extends Compartment
{
	public String notice()
	{
		System.out.println("This is a First Class");
		return "FirstClss";
	}
}
class LedisClass extends Compartment
{
	public String notice()
	{
		System.out.println("This is a LedisClass");
		return "LedisClass";
	}
}  
class GeneralClass extends Compartment
{
	public String notice()
	{
		System.out.println("This is a GeneralClass");
		return "GeneralClass";
	}
}  
class LaggegeClass extends Compartment
{
	public String notice()
	{
		System.out.println("This is a LaggegeClass");
		return "LaggegeClass";
	}
}  
  

public class TestCompartment
{
	public static void main(String[] args)
	{
		Random rendom = new Random();
		Compartment arry[] = new Compartment[10];
		int i;
	
		for(i =0; i< 10; i++)
		{
			int randomnumber = rendom.nextInt(4)+1;
			
			if(randomnumber == 1)
			{
				FirstClass fobj = new FirstClass();
				fobj.notice();
			
			}
			if(randomnumber == 2)
			{
				LedisClass ldobj = new LedisClass();
				ldobj.notice();
			}
			if(randomnumber == 3)
			{
				GeneralClass gobj = new GeneralClass();
				gobj.notice();
			}
			if(randomnumber == 4)
			{
				LaggegeClass lgobj = new LaggegeClass();
				lgobj.notice();
			}
		}
		
	}
}