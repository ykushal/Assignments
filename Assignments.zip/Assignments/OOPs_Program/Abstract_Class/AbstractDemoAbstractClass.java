abstract class AeroplaneAbstraction
{
	abstract void jounry();
	void show()
	{
		System.out.println("This is show mathod calling");
	}

}
class BritishAirlines1 extends AeroplaneAbstraction
{
	void jounry()
	{
		System.out.println("Jounrny from India to USA");
	}
	
}
class BritishAirlines2 extends AeroplaneAbstraction
{
	void jounry()
	{
		System.out.println("Jounrny from India to UAE");
	}
	
}
class AbstractDemoAbstractClass
{
	public static void main(String[] args)
	{
		
		BritishAirlines1 obj = new BritishAirlines1();
		obj.jounry();
		BritishAirlines2 obj1 = new BritishAirlines2();
		obj1.jounry();
	}
}