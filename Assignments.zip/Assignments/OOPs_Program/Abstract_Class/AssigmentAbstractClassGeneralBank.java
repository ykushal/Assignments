abstract class GeneralBank
{
	abstract void getSavingsIntrestRate();
	abstract void getFixedDepositIntrestRate();
} 
class ICICIBank extends GeneralBank
{
	void getSavingsIntrestRate()
	{
		System.out.println("ICICI Saving Intrest is 4 %");
	}
	void getFixedDepositIntrestRate()
	{
		System.out.println("ICICI Saving Intrest is 8.5%");
		
	}
}
class SBIBank extends GeneralBank
{
	void getSavingsIntrestRate()
	{
		System.out.println("SBIBank Saving Intrest is 4 %");
	}
	void getFixedDepositIntrestRate()
	{
		System.out.println("SBIBank Saving Intrest is 7%");
		
	}
	
}
public class AssigmentAbstractClassGeneralBank
{
	public static void main(String[] args)
	{
		SBIBank sbiobj = new SBIBank();
		ICICIBank iciciobj = new ICICIBank();
		System.out.println(" \t \t ICICI Bank Intrest rate is =");
		iciciobj.getFixedDepositIntrestRate();
		iciciobj.getSavingsIntrestRate();
		System.out.println();
		System.out.println("\t \tSBIBank Intrest rate is =");
		sbiobj.getFixedDepositIntrestRate();
		sbiobj.getSavingsIntrestRate();
	}
}