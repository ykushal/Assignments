interface A
{
	public abstract void show();
	public static final int a = 99;
}
class B implements A
{
	public void show()
	{
		System.out.println("this is a A class show mathod ");
	}
	
}
class InterfaceDemo
{
	public static void main(String[] args)
	{
		B obj = new B();
		obj.show();
	}
}