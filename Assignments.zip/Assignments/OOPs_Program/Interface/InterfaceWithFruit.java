interface Fruit
{
	void color(String color);
}
interface Fruit_Test
{
	
	void test(String test);
}

class InterfaceWithFruit implements Fruit,Fruit_Test
{
	String color;
	String test;
	public void color(String color)
	{
		this.color = color;
		System.out.println("Color of food is " + color );
	}
	public void test(String test )
	{
		this.test = test;
		System.out.println("Test of food is " + test );
	}
	public static void main(String[] args)
	{
		InterfaceWithFruit obj = new InterfaceWithFruit();
		obj.color("White");
		obj.test("Good");
	}
}