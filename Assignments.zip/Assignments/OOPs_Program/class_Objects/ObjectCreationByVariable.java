class ObjectCreationByVariable
{
	int a;
	void show()
	{
		System.out.println("This is a valu of a = " + a);
	}
	public static void main(String[] args)
	{
		ObjectCreationByVariable obj = new ObjectCreationByVariable();
		obj.a = 99;
		obj.show();
	}
}