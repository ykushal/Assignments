class ThisKeywordBox
{
	int width;
	int height;
	int dept;
	int volume;
	ThisKeywordBox(int width, int height,int dept)
	{
		this.width = width;
		this.height = height;
		this.dept = dept;
	}
	int volume()
	{
			volume = width * height * dept;
			System.out.println("volume is = " + volume);
			return volume;
	}
	public static void main(String[] args)
	{
		ThisKeywordBox obj = new ThisKeywordBox(2,3,4);
		obj.volume();
		
		
	}
}
