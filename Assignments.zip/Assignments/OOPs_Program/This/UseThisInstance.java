class UseThisInstance
{
	
		UseThisInstance t()
		{
			int i = 10;
			System.out.println("i is =" + i);
			return this;
		}
		
		public static void main(String[] args)
		{
			UseThisInstance obj = new UseThisInstance();
			obj.t();
		}
		
	
}