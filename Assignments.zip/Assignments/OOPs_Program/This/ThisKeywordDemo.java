class ThisKeywordDemo
{
			int i;
			int j;
			void sum(int i,int j)
			{
				System.out.println("i is without this =" + i);
				System.out.println("j is without this =" + j);
				this.i = i;
				this.j = j;
				System.out.println("sum is =" + (i + j));
			}
	public static void main(String[] args)
		{
			
			ThisKeywordDemo obj = new ThisKeywordDemo();
			obj.sum(4,5);
		}
}