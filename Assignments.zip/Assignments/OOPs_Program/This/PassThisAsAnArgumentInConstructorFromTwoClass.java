class PassThisAsAnArgumentInConstructorFromTwoClass
{
	public PassThisAsAnArgumentInConstructorFromTwoClass(PassThisAsAnArgumentInConstructorFromTwoClass2 t)
	{
		System.out.println("This is a PassThisAsAnArgumentInConstructorFromTwoClass class constructor ");
	}
}
public class PassThisAsAnArgumentInConstructorFromTwoClass2
{
	void t1()
	{
		PassThisAsAnArgumentInConstructorFromTwoClass obj1 = new PassThisAsAnArgumentInConstructorFromTwoClass(this);
		
	}
	public static void main(String[] args)
	{
	PassThisAsAnArgumentInConstructorFromTwoClass2 obj = new PassThisAsAnArgumentInConstructorFromTwoClass2();
	obj.t1();

	}
}