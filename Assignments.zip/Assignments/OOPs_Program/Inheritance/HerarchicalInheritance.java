class A
{
	void displayA()
	{
		System.out.println("Class A");
	}
}
class B extends A
{
	void displayB()
	{
		System.out.println("Class B");
	}
}
class HerarchicalInheritance extends A
{
	void displayC()
	{
		System.out.println("Class A");
	}
	public static void main(String[] args)
	{
		A obj1 = new A();
		obj1.displayA();
		B obj2 = new B();
		obj2.displayA();
		obj2.displayB();
		HerarchicalInheritance obj3 = new HerarchicalInheritance();
		obj3.displayA();
		obj3.displayC();
	}
}