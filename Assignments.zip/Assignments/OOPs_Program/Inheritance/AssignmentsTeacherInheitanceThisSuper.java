class Person
{
	String name;
	String dateOfBirth;
	Person(String name ,String dateOfBirth)
	{
		this.name = name ;
		this.dateOfBirth = dateOfBirth;
	}
	
}
class Teacher extends Person
{
	int salary;
	String subject;
	Teacher(String name, String dateOfBirth,int salary,String subject)
	{
		super(name,dateOfBirth);
		this.salary = salary;
		this.subject = subject;
	}
	void display()
	{
		System.out.println("Name of teacher is " + name);
		System.out.println("dateOfBirth of teacher is " + dateOfBirth);
		System.out.println("salary of teacher is " + salary);
		System.out.println("subject of teacher is " + subject);
	}

	
}
class Student extends Person
{
	int id ;
	Student(String name ,String dateOfBirth,int id)
	{
		super(name,dateOfBirth);
		this.id = id;
	}
}
class CollageSt extends Student
{
	String year;
	String collage_Name;
	CollageSt(String name,String dateOfBirth,int id ,String year,String collage_Name )
	{
		super(name,dateOfBirth,id);
		this.year = year;
		this.collage_Name = collage_Name;
	}
	void display()
	{
		System.out.println("Name of student is = " + name);
		System.out.println("dateOfBirth of student is = " + dateOfBirth);
		System.out.println("id of student is = " + id);
		System.out.println("year of student is = " + year);
		System.out.println("collage_Name of student is = " + collage_Name);
	}
	
}
class AssignmentsTeacherInheitanceThisSuper
{
	public static void main(String[] args)
	{
		Teacher obj = new Teacher("Abc","01/01/21",9000000,"Maths");
		obj.display();
		
		CollageSt obj1 = new CollageSt("Abccc","01/01/21",91,"2021","MIT");
		obj1.display();
		
		
		
	}
}