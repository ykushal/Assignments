class Fruit
{
	String name;
	String test;
	void eat(String name,String test)
	{
		this.name = name;
		this.test = test;
		System.out.println("name of fruit is = " + name);
		System.out.println("test of fruit is = " + test);
	}
}
class Apple extends Fruit
{
	String name;
	String test;
	void eat(String name,String test)
	{
		this.name = name;
		this.test = test;
		
		System.out.println("name of Fruit is = " + name);
		System.out.println("test of fruit is = " + test);
		
	}
}
class Orange extends Fruit
{
	String name;
	String test;
	void eat(String name,String test)
	{
		this.name = name;
		this.test = test;
		
		System.out.println("name of Fruit is =" + name);
		System.out.println("test of Fruit is =" + test);
	}
}
class FruitAssigInheritanceAndOverriding
{
	public static void main(String[] args)
	{
		Fruit obj = new Fruit();
		obj.eat("Fruit","Good");
		
		Apple obj1 = new Apple();
		obj1.eat("Apple","Sweet");
		
		Orange obj2 = new Orange();
		obj2.eat("Orange","Orangiee");
		
		
	}
}