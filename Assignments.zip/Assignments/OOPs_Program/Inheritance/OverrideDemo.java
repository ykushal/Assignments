class Vehical
{
	void run()
	{
		System.out.println("Vehical is ruuning ");
	}
}
class OverrideDemo extends Vehical
{
	void run()
	{
		System.out.println("car is ruuning ");
		
	}
	public static void main(String[] args)
	{
		Vehical obj = new Vehical();
		obj.run();
		OverrideDemo obj1 = new OverrideDemo();
		obj1.run();
		obj1.run();
		
	}
}