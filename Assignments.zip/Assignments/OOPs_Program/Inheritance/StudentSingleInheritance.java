class StudentName
{
	String name;
	void show(String name)
	{
		this.name = name;
		System.out.println("Name of Student is = " + name);
	}
}
class StudentSingleInheritance extends StudentName
{
	int id;
	void show(int id)
	{
		this.id = id;
		System.out.println("id of student is = " + id);
	}
	public static void main(String[] args)
	{
		StudentSingleInheritance obj = new StudentSingleInheritance();
		obj.show("Abc");
		obj.show(100);
	}
}