package com.yash.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Controller;

import com.yash.entities.Employee;

@Controller
public class EmployeeDao {

	@Autowired
	private HibernateTemplate hibernatetemp;
	
	@Transactional
	public void addEmployee(Employee emp) {
		
		this.hibernatetemp.saveOrUpdate(emp);
	}
	
	public List<Employee> getAllEmployee(){
		
		List<Employee> employees =this.hibernatetemp.loadAll(Employee.class);
		return employees;
	}
	
	@Transactional
	public void deleteEmployee(int empid) {
		
		Employee e=this.hibernatetemp.load(Employee.class, empid );
		this.hibernatetemp.delete(e);
	}
	
	public Employee getEmployee(int empid) {
		
		return this.hibernatetemp.get(Employee.class, empid);
	}
}
